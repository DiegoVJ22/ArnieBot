const { Telegraf } = require('telegraf')
const fs = require('fs');

// BOT TOKEN
const bot = new Telegraf('6912461196:AAG7slj9xqd2LvaiyQ2VXKda5WXfeEC5zVw')

// ID GRUPOS
const CONTROL_ID = -1002070474784  
const METDOX_ID = -1001740709687
const SPAM_ID = -4140427234

// FUNCION PARA OBTENER LA FECHA FORMATEADA

function getFecha(){
    // Obtenemos la fecha actual
    const currentDate = new Date();

    // Creamos funciones auxiliares para agregar ceros a la izquierda si el número es menor que 10
    const addLeadingZero = (num) => {
        return num < 10 ? '0' + num : num;
    };

    // Formateamos la fecha según el formato deseado
    const formattedDate =
        addLeadingZero(currentDate.getDate()) + '/' +
        addLeadingZero(currentDate.getMonth() + 1) + '/' +
        currentDate.getFullYear()

    return formattedDate
}

// VERIFICAR SI ALGUIEN YA ESTÁ REGISTRADO

function verificarUsuario(userId,ruta) {
    // Leer el archivo JSON actual
    const data = fs.readFileSync(ruta, 'utf8');
    const members = JSON.parse(data);

    // Verificar si el usuario ya está registrado
    return !members.some(member => member.id === userId);
}

// VERIFICA LA MEMBRESIA
function revisarMembresia(memberDate) {
    const today = new Date();
    const [day, month, year] = memberDate.split('/');
    const registrationDate = new Date(year, month - 1, day);
    const difference = today - registrationDate;
    const daysElapsed = difference / (1000 * 60 * 60 * 24);
    return daysElapsed >= 30;
}

// COMANDO START
bot.start((ctx)=>{

    ctx.reply("¡Hola! Bienvenido a MetDox.")

})

// COMANDO LISTAR
bot.command('listarDox', (ctx)=>{

    // Verificar si el comando se está ejecutando desde el grupo de control
    if (ctx.chat.id === CONTROL_ID) {
        // Leer el archivo JSON actual
        const data = fs.readFileSync('db/members.json', 'utf8');
        const members = JSON.parse(data);

        let userList = 'Usuarios de MetDox:\n\n';
        let cont = 0
        // Recorrer cada miembro y agregar su información a la cadena de texto
        members.forEach((member, index) => {
            userList += `${index + 1}. ${member.id} | ${member.username} | ${member.date}\n`;
            cont++
        });

        if (cont > 0) {
            userList += `\n Hay ${cont} usuarios activos`
            ctx.reply(userList)
        } else {
            ctx.reply('No hay usuarios registrados')
        }
    } else {
        ctx.reply('Este comando no está disponible');
    }

})

// COMANDO LISTAR
bot.command('listarSpam', (ctx)=>{

    // Verificar si el comando se está ejecutando desde el grupo de control
    if (ctx.chat.id === CONTROL_ID) {
        // Leer el archivo JSON actual
        const data = fs.readFileSync('db/spam.json', 'utf8');
        const members = JSON.parse(data);

        let userList = 'Usuarios de Spam:\n\n';
        let cont = 0
        // Recorrer cada miembro y agregar su información a la cadena de texto
        members.forEach((member, index) => {
            userList += `${index + 1}. ${member.id} | ${member.username} | ${member.date}\n`;
            cont++
        });

        if (cont > 0) {
            userList += `\n Hay ${cont} usuarios activos`
            ctx.reply(userList)
        } else {
            ctx.reply('No hay usuarios registrados')
        }
    } else {
        ctx.reply('Este comando no está disponible');
    }

})

// COMANDO VERIFY
bot.command('verifyDox', async(ctx)=>{

    if (ctx.chat.id === CONTROL_ID) {
        // Leer el archivo JSON actual
        const data = fs.readFileSync('db/members.json', 'utf8');
        let members = JSON.parse(data);

        // Obtener la lista de usuarios que han cumplido 30 días de membresía
        const expiredMembers = members.filter(member => revisarMembresia(member.date));

        // Si hay usuarios que han cumplido 30 días, eliminarlos del archivo JSON
        if (expiredMembers.length > 0) {
            members = members.filter(member => !revisarMembresia(member.date));

            // Escribir los datos actualizados en el archivo JSON
            fs.writeFileSync('db/members.json', JSON.stringify(members, null, 2));

            // Eliminar a los usuarios del grupo
            for (const member of expiredMembers) {
                await ctx.telegram.banChatMember(METDOX_ID,member.id)
                await ctx.reply(`La membresía de ${member.username} acabó`)
                await ctx.telegram.sendMessage(member.id, "Hola, tu membresía a MetDox acabó hoy. Si deseas renovar, por favor comunícate con uno de los vendedores @XeX_Morgan @XeX_Pikachu @xPadreDomingo .");
            }
        }
    } else {
        ctx.reply('Este comando no está disponible');
    }

})

// COMANDO VERIFY
bot.command('verifySpam', async(ctx)=>{

    if (ctx.chat.id === CONTROL_ID) {
        // Leer el archivo JSON actual
        const data = fs.readFileSync('db/spam.json', 'utf8');
        let members = JSON.parse(data);

        // Obtener la lista de usuarios que han cumplido 30 días de membresía
        const expiredMembers = members.filter(member => revisarMembresia(member.date));

        // Si hay usuarios que han cumplido 30 días, eliminarlos del archivo JSON
        if (expiredMembers.length > 0) {
            members = members.filter(member => !revisarMembresia(member.date));

            // Escribir los datos actualizados en el archivo JSON
            fs.writeFileSync('db/spam.json', JSON.stringify(members, null, 2));

            // Eliminar a los usuarios del grupo
            for (const member of expiredMembers) {
                await ctx.telegram.banChatMember(METDOX_ID,member.id)
                await ctx.reply(`La membresía de ${member.username} acabó`)
                await ctx.telegram.sendMessage(member.id, "Hola, tu membresía al Spam acabó hoy. Si deseas renovar, por favor comunícate con uno de los vendedores @XeX_Morgan @XeX_Pikachu @xPadreDomingo .");
            }
        }
    } else {
        ctx.reply('Este comando no está disponible');
    }

})

// COMANDO PARA EDITAR LA FECHA DE ENTRADA DE UN USUARIO
bot.command('setfechaDox', (ctx) => {
    if (ctx.chat.id === CONTROL_ID) {
        const commandArgs = ctx.message.text.split(' '); // Obtener los argumentos del comando
        const args = commandArgs[1].split('|'); // Separar el ID de usuario y la nueva fecha

        if (args.length !== 2) {
            ctx.reply('Formato incorrecto. Debe ser: /setfecha id|dd/mm/aaaa');
            return;
        }

        const userId = args[0].trim();
        const newDate = args[1].trim();

        // Verificar si el formato de fecha es válido (dd/mm/aaaa)
        const dateRegex = /^\d{2}\/\d{2}\/\d{4}$/;
        if (!dateRegex.test(newDate)) {
            ctx.reply('Formato de fecha incorrecto. Debe ser: dd/mm/aaaa');
            return;
        }

        // Leer el archivo JSON actual
        const data = fs.readFileSync('db/members.json', 'utf8');
        let members = JSON.parse(data);

        // Buscar el usuario por su ID
        const userIndex = members.findIndex(member => member.id == userId);
        if (userIndex == -1) {
            ctx.reply('Usuario no encontrado.');
            return;
        }

        // Actualizar la fecha de entrada del usuario
        members[userIndex].date = newDate;

        // Escribir los datos actualizados en el archivo JSON
        fs.writeFileSync('db/members.json', JSON.stringify(members, null, 2));

        ctx.reply(`La fecha ha sido actualizada`);
    } else {
        ctx.reply('Este comando no está disponible');
    }
});

// COMANDO PARA EDITAR LA FECHA DE ENTRADA DE UN USUARIO
bot.command('setfechaSpam', (ctx) => {
    if (ctx.chat.id === CONTROL_ID) {
        const commandArgs = ctx.message.text.split(' '); // Obtener los argumentos del comando
        const args = commandArgs[1].split('|'); // Separar el ID de usuario y la nueva fecha

        if (args.length !== 2) {
            ctx.reply('Formato incorrecto. Debe ser: /setfecha id|dd/mm/aaaa');
            return;
        }

        const userId = args[0].trim();
        const newDate = args[1].trim();

        // Verificar si el formato de fecha es válido (dd/mm/aaaa)
        const dateRegex = /^\d{2}\/\d{2}\/\d{4}$/;
        if (!dateRegex.test(newDate)) {
            ctx.reply('Formato de fecha incorrecto. Debe ser: dd/mm/aaaa');
            return;
        }

        // Leer el archivo JSON actual
        const data = fs.readFileSync('db/spam.json', 'utf8');
        let members = JSON.parse(data);

        // Buscar el usuario por su ID
        const userIndex = members.findIndex(member => member.id == userId);
        if (userIndex == -1) {
            ctx.reply('Usuario no encontrado.');
            return;
        }

        // Actualizar la fecha de entrada del usuario
        members[userIndex].date = newDate;

        // Escribir los datos actualizados en el archivo JSON
        fs.writeFileSync('db/spam.json', JSON.stringify(members, null, 2));

        ctx.reply(`La fecha ha sido actualizada`);
    } else {
        ctx.reply('Este comando no está disponible');
    }
});

// COMANDO PARA ELIMINAR A UN USUARIO POR SU ID
bot.command('deleteDox', (ctx) => {
    if (ctx.chat.id === CONTROL_ID) {
        const commandArgs = ctx.message.text.split(' '); // Obtener los argumentos del comando
        const userId = commandArgs[1]; // Obtener el ID del usuario a eliminar

        if (!userId) {
            ctx.reply('Debes proporcionar el ID del usuario a eliminar.');
            return;
        }

        // Leer el archivo JSON actual
        const data = fs.readFileSync('db/members.json', 'utf8');
        let members = JSON.parse(data);

        // Buscar el índice del usuario por su ID
        const userIndex = members.findIndex(member => member.id == userId);
        if (userIndex == -1) {
            ctx.reply('Usuario no encontrado.');
            return;
        }

        // Eliminar al usuario del arreglo
        const deletedUser = members.splice(userIndex, 1)[0];

        // Escribir los datos actualizados en el archivo JSON
        fs.writeFileSync('db/members.json', JSON.stringify(members, null, 2));

        ctx.reply(`El usuario ha sido eliminado.`);
    } else {
        ctx.reply('Este comando no está disponible');
    }
});

// COMANDO PARA ELIMINAR A UN USUARIO POR SU ID
bot.command('deleteSpam', (ctx) => {
    if (ctx.chat.id === CONTROL_ID) {
        const commandArgs = ctx.message.text.split(' '); // Obtener los argumentos del comando
        const userId = commandArgs[1]; // Obtener el ID del usuario a eliminar

        if (!userId) {
            ctx.reply('Debes proporcionar el ID del usuario a eliminar.');
            return;
        }

        // Leer el archivo JSON actual
        const data = fs.readFileSync('db/spam.json', 'utf8');
        let members = JSON.parse(data);

        // Buscar el índice del usuario por su ID
        const userIndex = members.findIndex(member => member.id == userId);
        if (userIndex == -1) {
            ctx.reply('Usuario no encontrado.');
            return;
        }

        // Eliminar al usuario del arreglo
        const deletedUser = members.splice(userIndex, 1)[0];

        // Escribir los datos actualizados en el archivo JSON
        fs.writeFileSync('db/spam.json', JSON.stringify(members, null, 2));

        ctx.reply(`El usuario ha sido eliminado.`);
    } else {
        ctx.reply('Este comando no está disponible');
    }
});

// COMANDO PARA REGISTRAR MANUALMENTE A UN USUARIO
bot.command('registerDox', (ctx) => {
    if (ctx.chat.id === CONTROL_ID) {
        const commandArgs = ctx.message.text.split(' '); // Obtener los argumentos del comando

        // Verificar si hay argumentos después del comando
        if (commandArgs.length <= 1) {
            ctx.reply('Formato incorrecto. Debe ser: /register ID|USERNAME|dd/mm/aaaa');
            return;
        }

        const args = commandArgs[1].split('|'); // Separar el ID, nombre de usuario y fecha

        if (args.length !== 3) {
            ctx.reply('Formato incorrecto. Debe ser: /register ID|USERNAME|dd/mm/aaaa');
            return;
        }

        const userId = args[0].trim();
        const username = args[1].trim();
        const date = args[2].trim();

        // Verificar si el formato de fecha es válido (dd/mm/aaaa)
        const dateRegex = /^\d{2}\/\d{2}\/\d{4}$/;
        if (!dateRegex.test(date)) {
            ctx.reply('Formato de fecha incorrecto. Debe ser: dd/mm/aaaa');
            return;
        }

        // Leer el archivo JSON actual
        const data = fs.readFileSync('db/members.json', 'utf8');
        let members = JSON.parse(data);

        // Verificar si el usuario ya está registrado
        if (members.some(member => member.id === userId)) {
            ctx.reply('El usuario ya está registrado.');
            return;
        }

        // Agregar al nuevo usuario al arreglo
        members.push({ id: userId, username, date });

        // Escribir los datos actualizados en el archivo JSON
        fs.writeFileSync('db/members.json', JSON.stringify(members, null, 2));

        ctx.reply(`Usuario registrado exitosamente.`);
    } else {
        ctx.reply('Este comando no está disponible');
    }
});

// COMANDO PARA REGISTRAR MANUALMENTE A UN USUARIO
bot.command('registerSpam', (ctx) => {
    if (ctx.chat.id === CONTROL_ID) {
        const commandArgs = ctx.message.text.split(' '); // Obtener los argumentos del comando

        // Verificar si hay argumentos después del comando
        if (commandArgs.length <= 1) {
            ctx.reply('Formato incorrecto. Debe ser: /register ID|USERNAME|dd/mm/aaaa');
            return;
        }

        const args = commandArgs[1].split('|'); // Separar el ID, nombre de usuario y fecha

        if (args.length !== 3) {
            ctx.reply('Formato incorrecto. Debe ser: /register ID|USERNAME|dd/mm/aaaa');
            return;
        }

        const userId = args[0].trim();
        const username = args[1].trim();
        const date = args[2].trim();

        // Verificar si el formato de fecha es válido (dd/mm/aaaa)
        const dateRegex = /^\d{2}\/\d{2}\/\d{4}$/;
        if (!dateRegex.test(date)) {
            ctx.reply('Formato de fecha incorrecto. Debe ser: dd/mm/aaaa');
            return;
        }

        // Leer el archivo JSON actual
        const data = fs.readFileSync('db/spam.json', 'utf8');
        let members = JSON.parse(data);

        // Verificar si el usuario ya está registrado
        if (members.some(member => member.id === userId)) {
            ctx.reply('El usuario ya está registrado.');
            return;
        }

        // Agregar al nuevo usuario al arreglo
        members.push({ id: userId, username, date });

        // Escribir los datos actualizados en el archivo JSON
        fs.writeFileSync('db/spam.json', JSON.stringify(members, null, 2));

        ctx.reply(`Usuario registrado exitosamente.`);
    } else {
        ctx.reply('Este comando no está disponible');
    }
});

// REGISTRA A NUEVOS MIEMBROS
bot.on('new_chat_members', (ctx)=>{

    if (ctx.chat.id == METDOX_ID){
        const newUser = ctx.message.new_chat_members[0]; // Obtener el primer nuevo miembro
        const userData = {
            id: newUser.id,
            username: newUser.username ? `@${newUser.username}` : newUser.first_name, 
            date: getFecha() 
        };

        if (verificarUsuario(userData.id,'db/members.json')){
            // Leer el archivo JSON actual
            fs.readFile('db/members.json', (err, data) => {
                if (err) throw err;

                let members = JSON.parse(data);
                members.push(userData);

                // Escribir los datos actualizados en el archivo JSON
                fs.writeFile('db/members.json', JSON.stringify(members, null, 2), (err) => {
                    if (err) throw err;
                    ctx.reply(`Bienvenido ${userData.username}`)
                });
            });
        }
    } else if (ctx.chat.id == SPAM_ID){
        const newUser = ctx.message.new_chat_members[0]; // Obtener el primer nuevo miembro
        const userData = {
            id: newUser.id,
            username: newUser.username ? `@${newUser.username}` : newUser.first_name, 
            date: getFecha() 
        };

        if (verificarUsuario(userData.id,'db/spam.json')){
            // Leer el archivo JSON actual
            fs.readFile('db/spam.json', (err, data) => {
                if (err) throw err;

                let members = JSON.parse(data);
                members.push(userData);

                // Escribir los datos actualizados en el archivo JSON
                fs.writeFile('db/spam.json', JSON.stringify(members, null, 2), (err) => {
                    if (err) throw err;
                    ctx.reply(`Bienvenido ${userData.username}`)
                });
            });
        }
    }
    
})

// COMANDO PARA ENVIAR UN AUDIO
bot.command('papacerdito', (ctx) => {
    // Ruta al archivo de audio
    const audioFilePath = __dirname + '/audios/papacerdito.mp3';

    // Verificar si el archivo existe
    fs.access(audioFilePath, fs.constants.F_OK, (err) => {
        if (err) {
            ctx.reply('El archivo de audio no se encontró.');
            return;
        }

        // Enviar el audio
        ctx.replyWithVoice({ source: audioFilePath });
    });
});


bot.launch()
